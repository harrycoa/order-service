package com.geekshirt.customerservice.util;

public enum AccountStatus {
    ACTIVE, INACTIVE;
}
