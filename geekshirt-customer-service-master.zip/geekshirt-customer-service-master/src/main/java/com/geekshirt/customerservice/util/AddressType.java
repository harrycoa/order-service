package com.geekshirt.customerservice.util;

public enum AddressType {
    HOME, MAILING
}
