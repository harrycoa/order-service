# geekshirt-customer-service
This Service provides an API to manage accounts and customers
