package com.geekshirt.orderservice.util;

public enum AccountStatus {
    ACTIVE, INACTIVE;
}
