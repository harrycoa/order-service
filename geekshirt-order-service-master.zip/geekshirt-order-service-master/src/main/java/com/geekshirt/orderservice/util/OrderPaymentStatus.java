package com.geekshirt.orderservice.util;

public enum OrderPaymentStatus {
    APPROVED, DENIED;
}
