package com.geekshirt.orderservice.util;

public enum OrderStatus {
    NA, PENDING, WAITING_FOR_MAIL_CARRIER, SHIPPED, ARRIVED_FACILITY, OUT_FOR_DELIVERY, DELIVERED;
}
