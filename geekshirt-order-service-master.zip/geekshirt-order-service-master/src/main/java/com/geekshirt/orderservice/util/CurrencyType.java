package com.geekshirt.orderservice.util;

public enum CurrencyType {
    USD, CAN, PESO_MX
}
