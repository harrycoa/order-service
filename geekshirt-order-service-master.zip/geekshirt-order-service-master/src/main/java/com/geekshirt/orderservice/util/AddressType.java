package com.geekshirt.orderservice.util;

public enum AddressType {
    HOME, MAILING
}
