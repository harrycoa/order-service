package com.geekshirt.orderservice.util;

public class Constants {
    public static final double TAX_IMPORT = 0.16;
}
