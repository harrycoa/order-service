package com.geekshirt.orderservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderServiceApplicationTests {

	public void contextLoads() {
	}
}
